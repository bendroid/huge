(function() {
  'use strict';

  angular.module('material-lite', [
    'ngRoute',
    'ngAnimate',
    'angular.mdl', // Required to make MDL components work with angular
    'ml.menu',
  ]);

})();
