module.exports.tasks = {
  sass: {
    blank: {
      files: {
        '<%= paths.src %>/css/material-lite-blank.css': '<%= paths.src %>/css/sass/material-lite-blank.scss'
      }
    }
  },
};
